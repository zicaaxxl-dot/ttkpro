/**
 * background.js — TikTok Shop Extractor PRO v1.5.0
 * Service Worker: gerencia dados entre abas e orquestra mensagens
 */
"use strict";

// capturedData[tabId] = PROJECT estruturado
const capturedData = {};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const tabId = sender.tab?.id;

  switch (msg.type) {
    // Content script capturou um produto
    case "PRODUCT_CAPTURED":
      if (tabId && msg.data) {
        // Merge inteligente: preserva dados já capturados se novo for parcial
        const prev = capturedData[tabId];
        capturedData[tabId] = mergeProjects(prev, msg.data);

        // Notifica popup se estiver aberto
        chrome.runtime
          .sendMessage({
            type: "DATA_UPDATED",
            tabId,
            data: capturedData[tabId],
          })
          .catch(() => {
            /* popup fechado, ignorar */
          });
      }
      sendResponse({ ok: true });
      break;

    // Popup pede dados da aba ativa
    case "GET_DATA":
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const id = tabs[0]?.id;
        sendResponse({ data: id ? capturedData[id] || null : null });
      });
      return true; // async

    case "INJECT_EXTRACTOR":
      chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
        const tab = tabs[0];
        if (!tab) {
          sendResponse({ ok: false, error: "Nenhuma aba ativa." });
          return;
        }
        try {
          // Dispara o evento (mantém compatibilidade com content.js, se existir o listener)
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => window.dispatchEvent(new CustomEvent("epro:extract")),
          });
          sendResponse({ ok: true });
        } catch (e) {
          sendResponse({ ok: false, error: e.message });
        }
      });
      return true;

    // Popup limpa dados
    case "CLEAR_DATA":
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const id = tabs[0]?.id;
        if (id) delete capturedData[id];
        sendResponse({ ok: true });
      });
      return true;
  }
});

/**
 * Mescla dois objetos PROJECT.
 * Campos do `next` sobrescrevem os do `prev`, exceto arrays vazios.
 */
function mergeProjects(prev, next) {
  if (!prev) return next;
  if (!next) return prev;

  const merged = { ...prev, ...next };

  // Basico: mescla campo a campo (não descarta dados já capturados)
  merged.basico = { ...prev.basico };
  for (const [k, v] of Object.entries(next.basico || {})) {
    if (v !== null && v !== "" && v !== undefined) {
      merged.basico[k] = v;
    }
  }

  // Arrays: usa o maior (mais completo)
  merged.reviews = pickLonger(prev.reviews, next.reviews);
  merged.variationGroups = pickLonger(
    prev.variationGroups,
    next.variationGroups,
  );

  return merged;
}

function pickLonger(a, b) {
  if (!a?.length) return b || [];
  if (!b?.length) return a || [];
  return a.length >= b.length ? a : b;
}

// Limpa dados de abas fechadas
chrome.tabs.onRemoved.addListener((tabId) => {
  delete capturedData[tabId];
});
