/**
 * popup.js — TikTok Shop Extractor PRO v1.5.0
 * Lógica completa do popup: extração via __MODERN_ROUTER_DATA__, preview, export, copy
 * v1.5.0: fallback de extração agora reporta o motivo real do erro (independente do content.js/inject.js)
 */
"use strict";

let currentData = null;
const $ = (id) => document.getElementById(id);

document.addEventListener("DOMContentLoaded", () => {
  loadStoredData();
  $("btnExtract").addEventListener("click", extractFromPage);
  $("btnCopyMain").addEventListener("click", copyAsMain);
  $("btnCopyRec").addEventListener("click", copyAsRec);
  $("btnExportJson").addEventListener("click", exportRaw);
  $("btnReset").addEventListener("click", resetState);
  $("detailToggle").addEventListener("click", toggleDetails);
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "DATA_UPDATED" && msg.data) {
    currentData = msg.data;
    renderProduct(currentData);
  }
});

function loadStoredData() {
  setStatus("loading", "Verificando página...");
  chrome.runtime.sendMessage({ type: "GET_DATA" }, (response) => {
    if (response?.data) {
      currentData = response.data;
      renderProduct(currentData);
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const url = tabs[0]?.url || "";
        if (url.includes("tiktok.com")) {
          setStatus(
            "idle",
            'Página TikTok detectada. Clique em "Extrair Produto".',
          );
        } else {
          setStatus("error", "Navegue até um produto no TikTok Shop.");
        }
      });
    }
  });
}

function extractFromPage() {
  const btn = $("btnExtract");
  btn.disabled = true;
  btn.innerHTML = '<span class="spin">⏳</span> Extraindo...';
  setStatus("loading", "Extraindo dados do produto...");

  chrome.runtime.sendMessage({ type: "INJECT_EXTRACTOR" }, (response) => {
    if (!response?.ok) {
      setStatus("error", response?.error || "Erro ao injetar extrator.");
      resetBtn(btn);
      return;
    }

    let attempts = 0;
    const poll = setInterval(() => {
      attempts++;
      chrome.runtime.sendMessage({ type: "GET_DATA" }, (res) => {
        if (res?.data?.basico?.title) {
          clearInterval(poll);
          currentData = res.data;
          renderProduct(currentData);
          resetBtn(btn);
        } else if (attempts >= 10) {
          clearInterval(poll);
          setStatus("loading", "Tentando extração direta...");
          tryDOMExtraction(btn);
        }
      });
    }, 500);
  });
}

/**
 * Fallback de extração manual — independente do content.js/inject.js.
 * Chama domExtractFull diretamente via chrome.scripting.executeScript
 * e mostra o motivo real do erro (em vez de uma mensagem genérica).
 */
function tryDOMExtraction(btn) {
  chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
    const tab = tabs[0];
    if (!tab) {
      setStatus("error", "Nenhuma aba ativa.");
      resetBtn(btn);
      return;
    }

    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: domExtractFull,
      });

      const raw = results?.[0]?.result;

      if (raw?.title) {
        const data = wrapDomDataInProject(raw);
        currentData = data;
        chrome.runtime.sendMessage({ type: "PRODUCT_CAPTURED", data });
        renderProduct(data);
        setStatus("active", "Produto extraído com sucesso!");
      } else {
        // Mostra o motivo real em vez de mensagem genérica
        const reason = raw?._error
          ? `Erro: ${raw._error}`
          : raw?._hasRouterData === false
            ? "Página sem dados de produto (__MODERN_ROUTER_DATA__ não encontrado). Você está numa página de produto (/pdp/...)?"
            : "Estrutura de dados não reconhecida nesta página.";
        setStatus("error", reason);
      }
    } catch (e) {
      setStatus("error", "Erro ao injetar script: " + e.message);
    }
    resetBtn(btn);
  });
}

/**
 * Função injetada diretamente na aba do usuário.
 * Lê __MODERN_ROUTER_DATA__ e navega pelas chaves REAIS do TikTok Shop:
 * product_model, promotion_model.promotion_product_price, review_info, shop_info
 *
 * Agora guarda o motivo real da falha em data._error / data._hasRouterData
 * em vez de falhar silenciosamente.
 */
function domExtractFull() {
  const data = {
    title: "",
    price: 0,
    price_original: 0,
    discount_text: "",
    description: "",
    images: [],
    reviews: [],
    variationGroups: [],
    shop: { name: "", avatar: "" },
    _source: "popup_router_data",
    _page_url: location.href,
    _hasRouterData: false,
    _error: null,
  };

  function cleanImg(urlList) {
    const u = Array.isArray(urlList) ? urlList[0] : urlList;
    if (!u || typeof u !== "string" || !u.startsWith("http")) return "";
    return u.split("?")[0];
  }

  // Descrição vem como string JSON serializada (array de blocos), não HTML
  function parseDescription(rawDesc) {
    if (!rawDesc) return "";
    let blocks;
    try {
      blocks = JSON.parse(rawDesc);
    } catch (_) {
      return String(rawDesc)
        .replace(/<[^>]+>/g, " ")
        .trim();
    }
    if (!Array.isArray(blocks)) return "";
    const lines = [];
    for (const b of blocks) {
      if (!b || !b.type) continue;
      if (b.type === "text" && b.text) lines.push(b.text);
      else if (b.type === "ul" && Array.isArray(b.content)) {
        b.content.forEach((item) => lines.push("• " + item));
      }
    }
    return lines.join("\n").trim();
  }

  // Acha o nó product_info dentro do loaderData, seja qual for a chave da rota
  function findProductInfo(routerData) {
    const loaderData = routerData?.loaderData;
    if (!loaderData || typeof loaderData !== "object") return null;

    // 1) Caminho padrão conhecido: loaderData[qualquerChave].product_info.product_model
    for (const key of Object.keys(loaderData)) {
      const node = loaderData[key];
      if (node?.product_info?.product_model) return node.product_info;
    }

    // 2) Fallback: TikTok às vezes muda a estrutura de rota (ex: envolve em "data",
    //    "props", "pageProps" etc). Faz busca recursiva por qualquer objeto que
    //    tenha product_model em algum nível e devolve o objeto que o contém
    //    diretamente (equivalente ao "product_info"), mesmo que o nome do
    //    campo pai tenha mudado.
    function deepFindProductInfo(obj, depth) {
      if (!obj || typeof obj !== "object" || depth > 8) return null;
      if (obj.product_model && typeof obj.product_model === "object") {
        return obj;
      }
      for (const k of Object.keys(obj)) {
        const val = obj[k];
        if (val && typeof val === "object") {
          const found = deepFindProductInfo(val, depth + 1);
          if (found) return found;
        }
      }
      return null;
    }

    return deepFindProductInfo(loaderData, 0);
  }

  try {
    const routerEl = document.getElementById("__MODERN_ROUTER_DATA__");
    if (!routerEl?.textContent) {
      data._hasRouterData = false;
      return data;
    }
    data._hasRouterData = true;

    const routerData = JSON.parse(routerEl.textContent);
    const productInfo = findProductInfo(routerData);
    if (!productInfo?.product_model) {
      const loaderKeys = Object.keys(routerData?.loaderData || {});
      data._error =
        "product_info.product_model não encontrado no loaderData (estrutura de rota mudou?). Chaves disponíveis: " +
        (loaderKeys.join(", ") || "(nenhuma)");
      return data;
    }

    const pm = productInfo.product_model;

    data.title = pm.name || "";
    data.description = parseDescription(pm.description);
    data.images = (pm.images || [])
      .map((img) => cleanImg(img.url_list))
      .filter(Boolean);

    // PREÇO — sempre em promotion_model.promotion_product_price, nunca em product_model
    const ppp = productInfo.promotion_model?.promotion_product_price;
    if (ppp?.min_price) {
      data.price = parseFloat(ppp.min_price.sale_price_decimal || 0) || 0;
      data.price_original =
        parseFloat(ppp.min_price.origin_price_decimal || 0) || 0;
      data.discount_text = ppp.range_price?.discount_txt || "";
    }

    // Mapa sku_id -> preço, pra cruzar com variações
    const skuPriceMap = {};
    for (const skuId of Object.keys(ppp?.skus_price || {})) {
      const sp = ppp.skus_price[skuId];
      skuPriceMap[skuId] = parseFloat(sp.sale_price_decimal || 0) || 0;
    }
    const valueIdToSkuId = {};
    (pm.skus || []).forEach((sku) => {
      (sku.property_pairs || []).forEach((pair) => {
        if (!valueIdToSkuId[pair.sku_property_value_id]) {
          valueIdToSkuId[pair.sku_property_value_id] = sku.sku_id;
        }
      });
    });

    // VARIAÇÕES — sale_properties[].property_values[], não sku_properties/attributes
    data.variationGroups = (pm.sale_properties || [])
      .map((prop) => ({
        name: prop.property_name || "Modelo",
        options: (prop.property_values || [])
          .map((val) => {
            const skuId = valueIdToSkuId[val.property_value_id];
            return {
              value: val.property_value_name || "",
              price: skuId ? skuPriceMap[skuId] || 0 : 0,
              image: cleanImg(val.image?.url_list),
              checkout_url: "",
            };
          })
          .filter((o) => o.value),
      }))
      .filter((g) => g.options.length);

    // REVIEWS — review_info.product_reviews[], campos reais
    const ri = productInfo.review_info;
    data.reviews = (ri?.product_reviews || []).map((r) => ({
      name: r.reviewer_name || "Cliente",
      stars: parseInt(r.review_rating || 5),
      text: r.review_text || "",
      image: r.reviewer_avatar_url || "",
      reviewImages: r.review_images || [],
    }));

    // LOJA — shop_info (mais completo) com fallback pra seller_model
    const si = productInfo.shop_info;
    const sm = productInfo.seller_model;
    data.shop.name = si?.shop_name || sm?.shop_name || "";
    data.shop.avatar =
      cleanImg(si?.shop_logo?.url_list) || cleanImg(sm?.shop_logo?.url_list);
  } catch (e) {
    data._error = e.message;
  }

  return data;
}

function wrapDomDataInProject(raw) {
  return {
    basico: {
      badge: "",
      title: raw.title || "",
      price: raw.price || 0,
      price_original: raw.price_original || 0,
      discount_text: raw.discount_text || "",
      description: raw.description || "",
      images: raw.images || [],
      own_checkout: true,
      external_link: raw._page_url || "",
      shop_name: raw.shop?.name || "",
      shop_avatar: raw.shop?.avatar || "",
    },
    reviews: raw.reviews || [],
    variationGroups: raw.variationGroups || [],
    recommendations: { discount: 40, items: [] },
    orderBumps: [],
    footer: { razao: "", cnpj: "", email: "", zap: "", pol: "", term: "" },
    _source: raw._source || "dom_fallback",
    _page_url: raw._page_url || "",
    _ts: Date.now(),
  };
}

function buildEditorProPayload(data, asRecommendation = false) {
  const b = data.basico || {};
  if (asRecommendation) {
    return {
      _epro_action: "add_recommendation",
      _epro_version: "3.0.0",
      recommendation: {
        title: b.title || "",
        price: b.price || 0,
        image: (b.images || [])[0] || "",
        checkout_url: b.external_link || "",
        variation_name: data.variationGroups?.[0]?.name || "Modelo",
        variations: (data.variationGroups?.[0]?.options || []).map((opt) => ({
          label: opt.value,
          price: opt.price || b.price || 0,
          image: opt.image || "",
          checkout_url: opt.checkout_url || "",
        })),
      },
    };
  }
  return {
    _epro_action: "set_main_product",
    _epro_version: "3.0.0",
    project: {
      name: slugify(b.title || "produto-importado"),
      basico: {
        badge: b.badge || "",
        title: b.title || "",
        price: b.price || 0,
        price_original: b.price_original || 0,
        discount_text: b.discount_text || "",
        description: b.description || "",
        images: b.images || [],
        own_checkout: b.own_checkout ?? true,
        external_link: b.external_link || "",
        shop_name: b.shop_name || "",
        shop_avatar: b.shop_avatar || "",
      },
      gateway: { provider: "cyberhub", public_key: "", secret_key: "" },
      orderBumps: data.orderBumps || [],
      reviews: (data.reviews || []).map((r) => ({
        name: r.name || "Cliente",
        stars: parseInt(r.stars) || 5,
        text: r.text || "",
        image: r.image || "",
        reviewImages: r.reviewImages || [],
      })),
      variationGroups: (data.variationGroups || []).map((g) => ({
        name: g.name || "Modelo",
        options: (g.options || []).map((opt) => ({
          value: opt.value || "",
          price: opt.price || 0,
          image: opt.image || "",
          checkout_url: opt.checkout_url || "",
        })),
      })),
      recommendations: data.recommendations || { discount: 40, items: [] },
      footer: data.footer || {
        razao: "",
        cnpj: "",
        email: "",
        zap: "",
        pol: "",
        term: "",
      },
    },
  };
}

function renderProduct(data) {
  if (!data?.basico?.title) {
    setStatus("error", "Dados incompletos. Tente extrair novamente.");
    return;
  }
  const b = data.basico || {};
  setStatus("active", "Produto extraído com sucesso!");
  $("emptyState").style.display = "none";
  $("productState").style.display = "block";

  const thumb = $("productThumb");
  if (b.images?.[0]) {
    thumb.src = b.images[0];
    thumb.onerror = () => {
      thumb.style.background = "#333";
      thumb.src = "";
    };
  } else {
    thumb.src = "";
  }
  $("productName").textContent = b.title || "—";
  $("productPrice").textContent = b.price
    ? "R$ " + fmtBRL(b.price)
    : "Consultar";

  const origEl = $("productPriceOrig");
  if (b.price_original && b.price_original > (b.price || 0)) {
    origEl.textContent = "R$ " + fmtBRL(b.price_original);
    origEl.style.display = "inline";
  } else {
    origEl.style.display = "none";
  }

  const reviews = data.reviews || [];
  const variations = data.variationGroups || [];
  const varOpts = variations.reduce((s, g) => s + (g.options?.length || 0), 0);
  const chips = [];
  if (b.images?.length) chips.push(`📷 ${b.images.length} fotos`);
  if (reviews.length) chips.push(`⭐ ${reviews.length} reviews`);
  if (varOpts) chips.push(`🎨 ${varOpts} variações`);
  if (b.description) chips.push("📝 desc");
  if (b.shop_name) chips.push(`🏪 ${b.shop_name.slice(0, 14)}`);
  $("productMeta").innerHTML = chips
    .map((c) => `<span class="meta-chip ok">${c}</span>`)
    .join("");

  $("productCard").classList.add("show");
  const strip = $("imgStrip");
  strip.innerHTML = "";
  (b.images || []).slice(0, 10).forEach((url) => {
    const img = document.createElement("img");
    img.className = "img-strip-item";
    img.src = url;
    img.onerror = () => img.remove();
    strip.appendChild(img);
  });
  buildDetailBody(data);
}

function buildDetailBody(data) {
  const b = data.basico || {};
  const reviews = data.reviews || [];
  const variations = data.variationGroups || [];
  const rows = [
    ["Título", b.title || "—"],
    ["Preço atual", b.price ? "R$ " + fmtBRL(b.price) : "—"],
    [
      "Preço original",
      b.price_original ? "R$ " + fmtBRL(b.price_original) : "—",
    ],
    ["Imagens", (b.images?.length || 0) + " enc."],
    ["Reviews", reviews.length],
    ["Variações", variations.length + " grupos"],
    ["Loja", b.shop_name || "—"],
    ["Descrição", b.description ? "Capturada com sucesso" : "—"],
    ["Fonte", data._source || "—"],
  ];
  $("detailBody").innerHTML = rows
    .map(
      ([label, value]) =>
        `<div class="detail-row"><span class="label">${label}</span><span class="value" title="${esc(String(value))}">${esc(String(value))}</span></div>`,
    )
    .join("");
}

function toggleDetails() {
  const isOpen = $("detailBody").classList.toggle("show");
  $("detailToggle").classList.toggle("open", isOpen);
}

async function copyAsMain() {
  if (!currentData) {
    toast("Nenhum dado extraído.");
    return;
  }
  await copyText(
    JSON.stringify(buildEditorProPayload(currentData, false), null, 2),
  );
  toast('✅ Copiado! Cole no Admin → "Colar como PRINCIPAL"');
  flashBtn("btnCopyMain", "✓ Copiado!", "Copiar como PRODUTO PRINCIPAL");
}

async function copyAsRec() {
  if (!currentData) {
    toast("Nenhum dado extraído.");
    return;
  }
  await copyText(
    JSON.stringify(buildEditorProPayload(currentData, true), null, 2),
  );
  toast('✅ Copiado! Cole no Admin → "Colar como RECOMENDAÇÃO"');
  flashBtn(
    "btnCopyRec",
    "✓ Recomendação copiada!",
    "Adicionar às RECOMENDAÇÕES",
  );
}

async function exportRaw() {
  if (!currentData) return;
  await copyText(JSON.stringify(currentData, null, 2));
  toast("📋 JSON bruto copiado!");
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch (_) {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.cssText = "position:fixed;opacity:0;top:0;left:0;";
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
  }
}

function flashBtn(id, tmpText, originalText) {
  const btn = $(id);
  if (!btn) return;
  const orig = btn.innerHTML;
  btn.textContent = tmpText;
  setTimeout(() => {
    btn.innerHTML = orig;
  }, 2500);
}

function resetState() {
  chrome.runtime.sendMessage({ type: "CLEAR_DATA" });
  currentData = null;
  $("emptyState").style.display = "block";
  $("productState").style.display = "none";
  $("productCard").classList.remove("show");
  setStatus("idle", 'Clique em "Extrair Produto" para começar.');
}

function resetBtn(btn) {
  if (!btn) return;
  btn.disabled = false;
  btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="width:16px;height:16px"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg> Extrair Produto da Página`;
}

function setStatus(type, text) {
  $("statusDot").className =
    "status-dot " +
    (type === "active"
      ? "active"
      : type === "loading"
        ? "loading"
        : type === "error"
          ? "error"
          : "");
  $("statusText").className =
    "status-text " +
    (type === "active" ? "ok" : type === "error" ? "error" : "");
  $("statusText").textContent = text;
}

function toast(msg, duration = 3200) {
  const existing = document.querySelector(".toast");
  if (existing) existing.remove();
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), duration);
}

function fmtBRL(n) {
  return Number(n)
    .toFixed(2)
    .replace(".", ",")
    .replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}
function slugify(str) {
  return (
    String(str)
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 40) || "produto"
  );
}
function esc(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/"/g, "&quot;");
}

const _style = document.createElement("style");
_style.textContent =
  "@keyframes spin{to{transform:rotate(360deg)}} .spin{display:inline-block;animation:spin .7s linear infinite}";
document.head.appendChild(_style);
