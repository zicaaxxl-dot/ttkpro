/**
 * admin_extension_handler.js — TikTok Shop Extractor PRO v1.5.0
 *
 * IMPORTANTE: este é o ÚNICO handler de importação da extensão que deve
 * existir na página. Se o admin.php tiver um <script> inline duplicado
 * fazendo a mesma coisa (initExtensionHandler), REMOVA-O — caso contrário
 * os dois vão brigar pelos mesmos botões e os campos param de preencher.
 */
(function initExtensionHandler() {
  "use strict";

  window.pasteFromExtensionMain = function () {
    const json = prompt("Cole o JSON copiado da extensão (Produto Principal):");
    if (!json) return;
    importPayload(json, false);
  };

  window.pasteFromExtensionRec = function () {
    const json = prompt("Cole o JSON copiado da extensão (Recomendação):");
    if (!json) return;
    importPayload(json, true);
  };

  function importPayload(jsonStr, forceAsRec) {
    let payload;
    try {
      payload = JSON.parse(jsonStr.trim());
    } catch (_) {
      showToast("❌ JSON inválido. Copie novamente da extensão.", "error");
      return;
    }

    const action = forceAsRec
      ? "add_recommendation"
      : payload._epro_action || "set_main_product";

    if (action === "add_recommendation") {
      handleRecommendation(payload);
    } else {
      handleMainProduct(payload);
    }
  }

  function handleMainProduct(payload) {
    const proj = payload.project;
    if (!proj?.basico) {
      showToast("❌ Estrutura de projeto inválida.", "error");
      return;
    }

    // TRAVA DE SEGURANÇA: Verifica se a ponte com o Admin existe
    if (!window.appProject) {
      showToast(
        "❌ Erro crítico: window.appProject não encontrado no Admin.",
        "error",
      );
      return;
    }

    const b = proj.basico;

    // ── 1. MERGE DIRETO NO OBJETO GLOBAL (fonte única de verdade) ──
    window.appProject.basico = { ...window.appProject.basico, ...b };

    if (proj.reviews?.length) {
      window.appProject.reviews = proj.reviews.map((r) => ({
        name: r.name || "Cliente",
        stars: parseInt(r.stars) || 5,
        text: r.text || "",
        image: r.image || "",
        reviewImages: r.reviewImages || [],
      }));
    } else if (Array.isArray(proj.reviews)) {
      window.appProject.reviews = [];
    }

    if (proj.variationGroups?.length) {
      window.appProject.variationGroups = proj.variationGroups.map((g) => ({
        name: g.name || "Modelo",
        options: (g.options || []).map((o) => ({
          value: o.value || "",
          price: o.price || 0,
          image: o.image || "",
          checkout_url: o.checkout_url || "",
        })),
      }));
    } else if (Array.isArray(proj.variationGroups)) {
      window.appProject.variationGroups = [];
    }

    if (proj.orderBumps?.length) {
      window.appProject.orderBumps = proj.orderBumps;
    }

    if (proj.recommendations?.items?.length) {
      window.appProject.recommendations = proj.recommendations;
    }

    if (proj.footer) {
      window.appProject.footer = {
        ...window.appProject.footer,
        ...proj.footer,
      };
    }

    // ── 2. RE-RENDERIZAÇÃO — usa a função do admin.php, que já preenche
    //       TODOS os campos (f_title, f_price, f_shop_name, f_ft_razao, etc.)
    //       a partir de window.appProject. Não tocamos em inputs aqui
    //       diretamente para não duplicar/divergir dos IDs reais do form. ──
    syncAndRefresh();

    const stats = [
      `${(b.images || []).length} fotos`,
      `${(proj.reviews || []).length} avaliações`,
      `${(proj.variationGroups || []).reduce((s, g) => s + (g.options?.length || 0), 0)} variações`,
    ].join(" · ");

    showToast(`✅ "${b.title || "Produto"}" importado — ${stats}`, "success");
  }

  function handleRecommendation(payload) {
    let rec = payload.recommendation;

    if (!rec && payload.project?.basico) {
      const b = payload.project.basico;
      rec = {
        title: b.title || "",
        price: b.price || 0,
        image: (b.images || [])[0] || "",
        checkout_url: b.external_link || "",
        variation_name: payload.project.variationGroups?.[0]?.name || "Modelo",
        variations: (payload.project.variationGroups?.[0]?.options || []).map(
          (o) => ({
            label: o.value,
            price: o.price || b.price || 0,
            image: o.image || "",
            checkout_url: o.checkout_url || "",
          }),
        ),
      };
    }

    if (!rec?.title) {
      showToast("❌ Payload de recomendação inválido.", "error");
      return;
    }

    if (!window.appProject) {
      showToast(
        "❌ Erro: O sistema (window.appProject) não foi encontrado.",
        "error",
      );
      return;
    }

    if (!window.appProject.recommendations) {
      window.appProject.recommendations = { discount: 40, items: [] };
    }

    window.appProject.recommendations.items.push({
      title: rec.title || "",
      price: rec.price || 0,
      image: rec.image || "",
      checkout_url: rec.checkout_url || "",
      variation_name: rec.variation_name || "Modelo",
      variations: rec.variations || [],
    });

    syncAndRefresh();

    const recTab = document.querySelector('[data-tab="recomendacoes"]');
    if (recTab) recTab.click();

    showToast(`✅ "${rec.title}" adicionado às recomendações!`, "success");
  }

  /**
   * Sincroniza window.appProject → formulário do admin.php.
   * Prioriza window.appSyncProjectToForm (já existe no admin.php e
   * usa os IDs corretos: f_title, f_price, f_shop_name, f_ft_razao, etc.)
   */
  function syncAndRefresh() {
    if (typeof window.appSyncProjectToForm === "function") {
      window.appSyncProjectToForm();
      return;
    }

    // Fallback apenas se o admin.php não expor a função global
    callIfExists("renderReviews");
    callIfExists("renderVariationGroups");
    callIfExists("renderBumps");
    callIfExists("renderRecommendations");
    callIfExists("renderImageThumbs");
    callIfExists("pushPreview");
    callIfExists("updateStorePreviews");
  }

  function callIfExists(fnName) {
    const camelApp = "app" + fnName.charAt(0).toUpperCase() + fnName.slice(1);
    if (typeof window[camelApp] === "function") {
      try {
        window[camelApp]();
      } catch (_) {}
    } else if (typeof window[fnName] === "function") {
      try {
        window[fnName]();
      } catch (_) {}
    }
  }

  function showToast(msg, type = "info") {
    if (typeof window.toast === "function") {
      window.toast(msg, type);
      return;
    }

    const existing = document.getElementById("__epro_toast__");
    if (existing) existing.remove();

    const el = document.createElement("div");
    el.id = "__epro_toast__";
    Object.assign(el.style, {
      position: "fixed",
      bottom: "20px",
      left: "50%",
      transform: "translateX(-50%)",
      background:
        type === "error"
          ? "#E3264C"
          : type === "success"
            ? "#00C896"
            : "#161823",
      color: "#fff",
      padding: "10px 20px",
      borderRadius: "24px",
      fontSize: "13px",
      fontWeight: "600",
      zIndex: "9999",
      boxShadow: "0 4px 16px rgba(0,0,0,.2)",
      animation: "eproToastIn .25s ease",
      whiteSpace: "nowrap",
    });
    el.textContent = msg;

    if (!document.getElementById("__epro_toast_style__")) {
      const s = document.createElement("style");
      s.id = "__epro_toast_style__";
      s.textContent =
        "@keyframes eproToastIn{from{opacity:0;transform:translate(-50%,8px)}to{opacity:1;transform:translate(-50%,0)}}";
      document.head.appendChild(s);
    }

    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3500);
  }

  function patchButtons() {
    const buttons = document.querySelectorAll(".tiktok-actions .btn");
    if (!buttons.length) {
      setTimeout(patchButtons, 300);
      return;
    }

    const btnMain = buttons[0];
    if (btnMain && !btnMain.dataset.eproPatched) {
      btnMain.dataset.eproPatched = "1";
      btnMain.addEventListener("click", window.pasteFromExtensionMain);
    }

    const btnRec = buttons[1];
    if (btnRec && !btnRec.dataset.eproPatched) {
      btnRec.dataset.eproPatched = "1";
      btnRec.addEventListener("click", window.pasteFromExtensionRec);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", patchButtons);
  } else {
    patchButtons();
    setTimeout(patchButtons, 500);
    setTimeout(patchButtons, 1500);
  }
})();
