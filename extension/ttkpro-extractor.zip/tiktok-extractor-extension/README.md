# TikTok Shop Extractor PRO — v1.5.0

## 📦 Instalação da Extensão

1. Abra o Chrome e vá em `chrome://extensions/`
2. Ative o **Modo do desenvolvedor** (canto superior direito)
3. Clique em **"Carregar sem compactação"**
4. Selecione a pasta `tiktok-extractor-extension`
5. A extensão aparecerá na barra de ferramentas com o ícone vermelho ✓

---

## O que foi aprimorado nesta versão

### inject.js

- **Detecção de produto em 3 camadas**: heurística direta → chaves conhecidas da API → varredura profunda até 12 níveis
- **Captura separada de reviews e dados da loja** — endpoints de `/review_list`, `/shop_detail` etc. são processados individualmente e mesclados
- **Reset automático ao trocar de produto** — MutationObserver detecta SPA navigation e limpa o bridge
- **Lê scripts JSON embutidos** além do `__NEXT_DATA__`

### content.js

- **Preços em todos os formatos**: `price_info`, `sku_list`, centavos (`price_in_cents`), formato BR e US
- **Imagens em máxima resolução**: converte URLs de `/thumbnail/` → `/origin/`, remove suffixos de resize
- **Imagens das variações** (cores com foto) capturadas corretamente
- **Avatares dos reviewers** + fotos enviadas na avaliação (`reviewImages`)
- **Dados da loja**: nome, avatar/logo, positiveRate — de endpoint próprio ou embutido no produto
- **DOM fallback detalhado** com seletores específicos do TikTok Shop para cada campo
- **Merge inteligente**: acumula reviews de múltiplas chamadas sem duplicar

### background.js

- **Merge de projetos**: preserva dados já capturados se nova resposta for parcial

### admin_extension_handler.js

- Preenche `f_shop_avatar`, `f_shop_name`, `f_shop_positive_rate`
- Popula `project.reviews` com `image` (avatar) e `reviewImages` (fotos do produto)
- Popula `project.variationGroups` com `image` por opção de variação
- `setField()` dispara eventos `input` e `change` para acionar reactive frameworks
- Toast visual sem depender de função do admin (fallback genérico)
- Patch de botões com retry (cobre botões criados dinamicamente pelo admin)

## Estrutura de arquivos

```
tiktok-extractor-extension/
├── manifest.json
├── background.js
├── content.js
├── inject.js
├── popup.html
├── popup.js
├── admin_extension_handler.js
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```

## Campos extraídos

| Campo                       | Fonte        |
| --------------------------- | ------------ |
| Título                      | API + DOM    |
| Preço atual                 | API + DOM    |
| Preço original (De/Por)     | API + DOM    |
| Texto de desconto (auto)    | Calculado    |
| Badge/etiqueta              | API + DOM    |
| Descrição                   | API + DOM    |
| Imagens do produto (até 12) | API + DOM    |
| **Avatar da loja**          | API + DOM ✨ |
| **Nome da loja**            | API + DOM ✨ |
| Avaliações (até 12)         | API + DOM    |
| **Avatar de cada reviewer** | API + DOM ✨ |
| **Fotos das reviews**       | API + DOM ✨ |
| Variações (grupos + opções) | API + DOM    |
| **Foto de cada variação**   | API + DOM ✨ |
| Preço por variação (SKU)    | API          |

✨ = novo na v1.5.0
