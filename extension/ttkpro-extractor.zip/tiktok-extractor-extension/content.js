/**
 * content.js — TikTok Shop Extractor PRO v1.5.0
 */
(function () {
  "use strict";
  if (window.__eproContent__) return;
  window.__eproContent__ = true;

  const STATE = { product: null, reviews: [], shop: null, variationGroups: [] };

  const injectScript = document.createElement("script");
  injectScript.src = chrome.runtime.getURL("inject.js");
  injectScript.onload = function () {
    this.remove();
  };
  (document.head || document.documentElement).appendChild(injectScript);

  window.addEventListener("epro:extract", () => {
    // Força o inject.js a re-rodar a leitura do __MODERN_ROUTER_DATA__
    const tryAgain = document.getElementById("__MODERN_ROUTER_DATA__");
    if (tryAgain?.textContent) {
      window.dispatchEvent(new CustomEvent("__epro_force_reextract__"));
    }
    // Dá um tempo curto e força o envio do que já tiver em STATE,
    // mesmo que parcial, para não travar o popup
    setTimeout(() => rebuildAndSend(), 600);
  });

  window.addEventListener("__epro_raw__", (e) => {
    const { type, payload } = e.detail;
    if (type === "product" && payload) STATE.product = payload;
    else if (type === "reviews" && Array.isArray(payload))
      STATE.reviews = payload;
    else if (type === "shop" && payload) STATE.shop = payload;
    else if (type === "variationGroups" && Array.isArray(payload))
      STATE.variationGroups = payload;
    rebuildAndSend();
  });

  let _sendTimer = null;
  function rebuildAndSend() {
    clearTimeout(_sendTimer);
    _sendTimer = setTimeout(() => {
      const structured = buildProject();
      if (!structured?.basico?.title) return;
      chrome.runtime.sendMessage({
        type: "PRODUCT_CAPTURED",
        data: structured,
      });
    }, 300);
  }

  function buildProject() {
    const raw = STATE.product;
    if (!raw?.title) return null;

    return {
      basico: {
        title: raw.title,
        price: raw.price || 0,
        price_original: raw.price_original || 0,
        discount_text: raw.discount_text || "",
        description: raw.description || "",
        images: raw.images || [],
        badge: raw.badge || "",
        own_checkout: true,
        external_link: raw.external_link || "",
        shop_name: STATE.shop?.name || "",
        shop_avatar: STATE.shop?.avatar || "",
        shop_positive_rate: STATE.shop?.followers || "",
      },
      reviews: STATE.reviews.map((r) => ({
        name: r.name,
        stars: r.stars,
        text: r.text,
        image: r.image,
        reviewImages: r.reviewImages,
      })),
      variationGroups: STATE.variationGroups,
      recommendations: { discount: 40, items: [] },
      footer: { razao: "", cnpj: "", email: "", zap: "", pol: "", term: "" },
      _source: "ssr_modern_router_data",
    };
  }
})();
