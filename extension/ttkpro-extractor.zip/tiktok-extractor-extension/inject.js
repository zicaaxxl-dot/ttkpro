/**
 * inject.js — TikTok Shop Extractor PRO v1.5.0
 * Lê diretamente __MODERN_ROUTER_DATA__ e navega pelas chaves REAIS:
 * product_model, promotion_model.promotion_product_price, review_info, shop_info
 */
(function () {
  "use strict";
  if (window.__epro_inject__) return;
  window.__epro_inject__ = true;

  function safeJson(text) {
    try {
      return JSON.parse(text);
    } catch (_) {
      return null;
    }
  }

  function dispatch(type, payload) {
    window.dispatchEvent(
      new CustomEvent("__epro_raw__", { detail: { type, payload } }),
    );
  }

  // ── Acha o nó product_info dentro do loaderData, seja qual for a chave da rota ──
  function findProductInfo(routerData) {
    const loaderData = routerData?.loaderData;
    if (!loaderData || typeof loaderData !== "object") return null;
    for (const key of Object.keys(loaderData)) {
      const node = loaderData[key];
      if (node?.product_info?.product_model) return node.product_info;
    }
    return null;
  }

  // ── Descrição: vem como STRING JSON serializada (array de blocos), não HTML ──
  function parseDescription(rawDesc) {
    if (!rawDesc) return "";
    let blocks;
    try {
      blocks = JSON.parse(rawDesc);
    } catch (_) {
      return String(rawDesc)
        .replace(/<[^>]+>/g, " ")
        .trim();
    }
    if (!Array.isArray(blocks)) return "";
    const lines = [];
    for (const b of blocks) {
      if (!b || !b.type) continue;
      if (b.type === "text" && b.text) lines.push(b.text);
      else if (b.type === "ul" && Array.isArray(b.content)) {
        b.content.forEach((item) => lines.push("• " + item));
      }
      // type "image" é ignorado aqui (vai pra galeria, não pra descrição em texto puro)
    }
    return lines.join("\n").trim();
  }

  function cleanImg(urlList, fallbackUrl) {
    const u = Array.isArray(urlList) ? urlList[0] : urlList || fallbackUrl;
    if (!u || typeof u !== "string" || !u.startsWith("http")) return "";
    return u.split("?")[0];
  }

  // ── Preço: vive em promotion_model.promotion_product_price, NÃO em product_model ──
  function extractPricing(productInfo) {
    const ppp = productInfo?.promotion_model?.promotion_product_price;
    if (!ppp) return { price: 0, priceOriginal: 0, skuPriceMap: {} };

    const min = ppp.min_price || {};
    const price = parseFloat(min.sale_price_decimal || 0) || 0;
    const priceOriginal = parseFloat(min.origin_price_decimal || 0) || 0;

    const skuPriceMap = {};
    const skusPrice = ppp.skus_price || {};
    for (const skuId of Object.keys(skusPrice)) {
      const sp = skusPrice[skuId];
      skuPriceMap[skuId] = {
        price: parseFloat(sp.sale_price_decimal || 0) || 0,
        priceOriginal: parseFloat(sp.origin_price_decimal || 0) || 0,
      };
    }
    return {
      price,
      priceOriginal,
      skuPriceMap,
      discountText: ppp.range_price?.discount_txt || "",
    };
  }

  // ── Variações: sale_properties[].property_values[], cruzando preço via skus[] ──
  function extractVariations(pm, skuPriceMap) {
    const saleProps = pm.sale_properties || [];
    if (!saleProps.length) return [];

    // mapa: property_value_id -> sku_id (pra achar o preço daquele valor)
    const valueIdToSkuId = {};
    (pm.skus || []).forEach((sku) => {
      (sku.property_pairs || []).forEach((pair) => {
        if (!valueIdToSkuId[pair.sku_property_value_id]) {
          valueIdToSkuId[pair.sku_property_value_id] = sku.sku_id;
        }
      });
    });

    return saleProps
      .map((prop) => ({
        name: prop.property_name || "Modelo",
        options: (prop.property_values || [])
          .map((val) => {
            const skuId = valueIdToSkuId[val.property_value_id];
            const priceInfo = skuId ? skuPriceMap[skuId] : null;
            return {
              value: val.property_value_name || "",
              price: priceInfo ? priceInfo.price : 0,
              image: cleanImg(val.image?.url_list),
              checkout_url: "",
            };
          })
          .filter((o) => o.value),
      }))
      .filter((g) => g.options.length);
  }

  // ── Reviews: review_info.product_reviews[], campos reais ──
  function extractReviews(productInfo) {
    const ri = productInfo?.review_info;
    if (!ri?.product_reviews) return [];
    return ri.product_reviews.map((r) => ({
      name: r.reviewer_name || "Cliente",
      stars: parseInt(r.review_rating || 5),
      text: r.review_text || "",
      image: r.reviewer_avatar_url || "",
      reviewImages: r.review_images || [],
      sku: r.sku_specification || "",
    }));
  }

  // ── Loja: shop_info (mais completo) com fallback pra seller_model ──
  function extractShop(productInfo) {
    const si = productInfo?.shop_info;
    const sm = productInfo?.seller_model;
    const name = si?.shop_name || sm?.shop_name || "";
    const avatar =
      cleanImg(si?.shop_logo?.url_list) || cleanImg(sm?.shop_logo?.url_list);
    return {
      name,
      avatar,
      soldCount: si?.format_sold_count || "",
      followers: si?.format_followers_count || "",
    };
  }

  function buildFromRouterData(routerData) {
    const productInfo = findProductInfo(routerData);
    if (!productInfo?.product_model) return;

    const pm = productInfo.product_model;
    const { price, priceOriginal, skuPriceMap, discountText } =
      extractPricing(productInfo);

    const images = (pm.images || [])
      .map((img) => cleanImg(img.url_list))
      .filter(Boolean);

    const product = {
      title: pm.name || "",
      description: parseDescription(pm.description),
      price,
      price_original: priceOriginal,
      discount_text: discountText,
      images,
      badge: "",
      external_link: location.href.split("?")[0],
    };

    dispatch("product", product);
    dispatch("shop", extractShop(productInfo));
    dispatch("reviews", extractReviews(productInfo));
    dispatch("variationGroups", extractVariations(pm, skuPriceMap));
  }

  function tryStaticData() {
    const routerEl = document.getElementById("__MODERN_ROUTER_DATA__");
    if (routerEl?.textContent) {
      const json = safeJson(routerEl.textContent);
      if (json) {
        buildFromRouterData(json);
        return;
      }
    }
  }

  if (
    document.readyState === "complete" ||
    document.readyState === "interactive"
  ) {
    tryStaticData();
  } else {
    window.addEventListener("load", tryStaticData);
  }

  window.addEventListener("__epro_force_reextract__", tryStaticData);

  let _lastHref = location.href;
  new MutationObserver(() => {
    if (location.href !== _lastHref) {
      _lastHref = location.href;
      setTimeout(tryStaticData, 800);
      setTimeout(tryStaticData, 2000);
    }
  }).observe(document.documentElement, { childList: true, subtree: false });
})();
